// Angular
import './controllers/CloneProjectController'
import './controllers/CloneProjectModalController'

// React
import '../../features/clone-project-modal/controllers/left-menu-clone-project-modal-controller'
