import App from '../../../base'
import { react2angular } from 'react2angular'

import SymbolPalette from '../components/symbol-palette'

App.component('symbolPalette', react2angular(SymbolPalette))
