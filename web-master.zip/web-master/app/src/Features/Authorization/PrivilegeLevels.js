const PrivilegeLevels = {
  NONE: false,
  READ_ONLY: 'readOnly',
  READ_AND_WRITE: 'readAndWrite',
  OWNER: 'owner',
}

module.exports = PrivilegeLevels
