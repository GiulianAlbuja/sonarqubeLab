module.exports = {
  READ_ONLY: 'readOnly', // LEGACY
  READ_AND_WRITE: 'readAndWrite', // LEGACY
  PRIVATE: 'private',
  TOKEN_BASED: 'tokenBased',
}
