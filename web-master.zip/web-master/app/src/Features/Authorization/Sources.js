module.exports = {
  INVITE: 'invite',
  TOKEN: 'token',
  OWNER: 'owner',
}
