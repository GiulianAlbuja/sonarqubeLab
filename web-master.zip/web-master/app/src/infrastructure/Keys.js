// TODO: This file was created by bulk-decaffeinate.
// Sanity-check the conversion and remove this comment.
module.exports = {
  queue: {
    web_to_tpds_http_requests: 'web_to_tpds_http_requests',
    tpds_to_web_http_requests: 'tpds_to_web_http_requests',
  },
}
